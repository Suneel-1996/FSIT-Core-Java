package model;

public class CustomException extends Exception{
public CustomException(String s) {
	super(s);
}
}


