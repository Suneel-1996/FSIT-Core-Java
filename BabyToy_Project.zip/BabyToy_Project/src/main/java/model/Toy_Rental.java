package model;

import service.DrawLine;

public class Toy_Rental {
	int Rental_Id;
	int Customer_Id;
	int Toy_Id;
	String  Rental_Start_Date;
	String Rental_End_Date;
	float Rental_Amount_Per_Day;
	float Total_Amount;
	float Fine;
	String Status;
	public int getRental_Id() {
		return Rental_Id;
	}
	public void setRental_Id(int rental_Id) {
		Rental_Id = rental_Id;
	}
	public int getCustomer_Id() {
		return Customer_Id;
	}
	public void setCustomer_Id(int customer_Id) {
		Customer_Id = customer_Id;
	}
	public int getToy_Id() {
		return Toy_Id;
	}
	public void setToy_Id(int toy_Id) {
		Toy_Id = toy_Id;
	}
	public String getRental_Start_Date() {
		return Rental_Start_Date;
	}
	public void setRental_Start_Date(String rental_Start_Date) {
		Rental_Start_Date = rental_Start_Date;
	}
	public String getRental_End_Date() {
		return Rental_End_Date;
	}
	public void setRental_End_Date(String rental_End_Date) {
		Rental_End_Date = rental_End_Date;
	}
	public float getRental_Amount_Per_Day() {
		return Rental_Amount_Per_Day;
	}
	public void setRental_Amount_Per_Day(float rental_Amount_Per_Day) {
		Rental_Amount_Per_Day = rental_Amount_Per_Day;
	}
	public float getTotal_Amount() {
		return Total_Amount;
	}
	public void setTotal_Amount(float total_Amount) {
		Total_Amount = total_Amount;
	}
	public float getFine() {
		return Fine;
	}
	public void setFine(float fine) {
		Fine = fine;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
}
