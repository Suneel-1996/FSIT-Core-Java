package model;

public class ElectronicToy extends Toy{
 int noOfBatteries;
 String operatingMode;
 
}
