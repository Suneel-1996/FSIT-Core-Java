package model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Customer{
 public Customer() {
	 
 }
	 public Customer(int customer_Id, String customer_Name, String password, String city, String state, long zip,
			String country) throws CustomException {
		super();
		Pattern pattern1=Pattern.compile("[$&+,:;=\\\\\\\\?@#|/'<>.^*()%!-]");
		Pattern pattern2=Pattern.compile("[0-9]");
		
		Matcher matcher1 =pattern1.matcher(customer_Name);
		Matcher matcher2=pattern2.matcher(customer_Name);
		
		if((customer_Name.length()>=6) && !(matcher1.find()) && !(matcher2.find())) {
			this.customer_Name = customer_Name;
		}
		else {
			throw new CustomException("InvalidNameException");
		}
		this.customer_Id = customer_Id;
		this.customer_Name = customer_Name;
		this.password = password;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.country = country;
	}
	int customer_Id;
	 String customer_Name;
	 String password;
	 String city;
	 String state;
	 long zip;
	 String country;
	public int getCustomer_Id() {
		return customer_Id;
	}
	public void setCustomer_Id(int customer_Id) {
		this.customer_Id = customer_Id;
	}
	public String getCustomer_Name() {
		return customer_Name;
	}
	public void setCustomer_Name(String customer_Name) throws CustomException {
		Pattern pattern1=Pattern.compile("[$&+,:;=\\\\\\\\?@#|/'<>.^*()%!-]");
		Pattern pattern2=Pattern.compile("[0-9]");
		
		Matcher matcher1 =pattern1.matcher(customer_Name);
		Matcher matcher2=pattern2.matcher(customer_Name);
		
		if((customer_Name.length()>=6) && !(matcher1.find()) && !(matcher2.find())) {
			this.customer_Name = customer_Name;
		}
		else {
			throw new CustomException("InvalidNameException");
		}
		
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getZip() {
		return zip;
	}
	public void setZip(long zip) {
		this.zip = zip;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	 public String toString() {
		 String maskPassword = this.password.replaceAll(".","*");
		 String value ="Customer_id is: "+this.customer_Id+"\nCustomer_Name is: "+this.customer_Name+"\nPassword is: "+maskPassword+"\nCustomer_City is: "+this.city+"\nState is: "+this.state+"\nZip is: "+this.zip+"\nCountry is: "+this.country;
		//System.out.println(value);	
		 return value;
	 }
	 
 
}
