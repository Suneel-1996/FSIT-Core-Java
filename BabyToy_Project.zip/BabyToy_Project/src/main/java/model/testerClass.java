package model;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class testerClass {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
	      Date d1 = sdformat.parse("2019-08-15");
	      Date d2 = sdformat.parse("2019-08-10");
	      System.out.println(d1.compareTo(d2));
	      System.out.println(d1.getDate()-d2.getDate());
	      System.out.println((d1.getTime()-d2.getTime())/(1000 * 60 * 60 * 24)%365);
	      
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		Calendar c= Calendar.getInstance();
		System.out.println(sdf.format(c.getTime()).toString());
		c.add(Calendar.DAY_OF_MONTH, 2);
		String a=c.getTime().toString();
		
		System.out.println(sdf.format(c.getTime()));
		c.add(Calendar.DAY_OF_MONTH, -2);
		
		String s1=sdf.format(c.getTime());
		System.out.println(sdf.format(c.getTime()));
		
		System.exit(0);
		String val ="hee man";
		Pattern pattern1=Pattern.compile("[ $&+,:;=\\\\\\\\?@#|/'<>.^*()%!-]");
		Pattern pattern2=Pattern.compile("[0-9]");
		
		Matcher matcher1 =pattern1.matcher(val);
		Matcher matcher2=pattern2.matcher(val);
		
		System.out.println(matcher1);
		System.out.println(matcher1.find());
		System.out.println(matcher2.find());
	}

}
