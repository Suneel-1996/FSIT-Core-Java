package model;

public class Toy {
public Toy(int toy_Id, String toy_Name, String toy_Type, float min_Age, float max_age, float price, int quantity,
			float rental_Amount) throws CustomException {
		super();
		this.toy_Id = toy_Id;
		this.toy_Name = toy_Name;
		this.toy_Type = toy_Type;
		if(this.min_Age>=0 || this.min_Age<=12) {
			this.min_Age = min_Age;	
		}
		else {
			throw new CustomException("InvalidAgeException");
		}
		if(this.max_age>=0 || this.max_age<=12) {
			this.max_age = max_age;	
		}
		else {
			throw new CustomException("InvalidAgeException");
		}
		
		this.price = price;
		this.quantity = quantity;
		this.rental_Amount = rental_Amount;
	}
public Toy() {
	
}
int toy_Id;
String toy_Name;
String toy_Type;
float min_Age;
float max_age;
float price;
int quantity;
float rental_Amount;
public int getToy_Id() {
	return toy_Id;
}
public void setToy_Id(int toy_Id) {
	this.toy_Id = toy_Id;
}
public String getToy_Name() {
	return toy_Name;
}
public void setToy_Name(String toy_Name) {
	this.toy_Name = toy_Name;
}
public String getToy_Type() {
	return toy_Type;
}
public void setToy_Type(String toy_Type) {
	this.toy_Type = toy_Type;
}
public float getMin_Age() {
	
	return min_Age;
}
public void setMin_Age(float min_Age) throws CustomException {
	if(min_Age>=0 || min_Age<=12) {
		this.min_Age = min_Age;	
	}
	else {
		throw new CustomException("InvalidAgeException");
	}
}
public float getMax_age() {
	return max_age;
}
public void setMax_age(float max_age) throws CustomException {
	
	if(min_Age>=0 || min_Age<=12) {
		this.max_age = max_age;
	}
	else {
		throw new CustomException("InvalidAgeException");
	}
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public float getRental_Amount() {
	return rental_Amount;
}
public void setRental_Amount(float rental_Amount) {
	this.rental_Amount = rental_Amount;
}
public String toString() {
	String value ="Toy_Id is: "+this.toy_Id+"\nToy_Name is: "+this.toy_Name+"\nToy_Type is: "+this.toy_Type+"\nMin_Age is: "+this.min_Age+"\nMax_Age is: "+this.max_age+"\nPrice is: "+this.price+"\nQuantity is: "+this.quantity+"\nRental_Amount is: "+this.rental_Amount;
	return value;
}
}
