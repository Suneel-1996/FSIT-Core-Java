package model;

public class MusicalToy {
	int noOfBatteries;
	 String operatingMode;
	 int noOfSpeakers;
}
