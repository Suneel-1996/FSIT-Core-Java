package App;

import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

import model.CustomException;
import model.Customer;
import model.Toy;
import service.CustomerService;
import service.CustomerServiceImpl;
import service.DrawLine;
import service.ToyRentalService;
import service.ToyRentalServiceImpl;
import service.ToyService;
import service.ToyServiceImpl;

public class TestApp {

	public static void main(String[] args) throws CustomException, ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean doYouWantToContinue=true;
		
		Scanner scan = new Scanner(System.in);
		do {
			doYouWantToContinue=false;
			System.out.println("**********************WELCOME BABY TOYS**********************");
			System.out.println("Please select one from the below:                           *");
			System.out.println("1. Customer Register                                        *");
			System.out.println("2. Customer Login                                           *");
			System.out.println("3. Search Customer                                          *");
			System.out.println("4. View All Customers                                       *");
			System.out.println("5. Add Toy                                                  *");
			System.out.println("6. Search Toy                                               *");
			System.out.println("7. View All Toys                                            *");
			System.out.println("8. Book a Toy                                               *");
			System.out.println("9. Return a Toy                                             *");
			System.out.println("**********************WELCOME BABY TOYS**********************");
			int input=scan.nextInt();
			
			switch (input) {
				case 1:
					try {
						int customer_Id=0;
						String customer_Name="";
						String password="";
						String city="";
						String state="";
						long zip=0;
						String country="";
						customer_Id=Integer.parseInt(JOptionPane.showInputDialog("Customer_Id"));
						
						System.out.println("YOU HAVE CHOOSEN CUSTOMER REGISTER");
						DrawLine.drawLine("-", 60);
						CustomerService cs= new CustomerServiceImpl();
						
						
						//scan.next();
						
					
						customer_Name=JOptionPane.showInputDialog("Customer_Name");
						password=JOptionPane.showInputDialog("Password");
						
						
						city=JOptionPane.showInputDialog("City");
						
						state=JOptionPane.showInputDialog("State");
						
						zip=Long.parseLong(JOptionPane.showInputDialog("Postal/Zip Code"));
						
						country=JOptionPane.showInputDialog("Country");
						
						
						
						
						Customer customer = new Customer(customer_Id, customer_Name, password, city, state, zip, country);
						cs.insert(customer);
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println(e.getMessage());
					}
					
					DrawLine.drawLine("-", 60);
					break;
				case 2:
					System.out.println("YOU HAVE CHOOSEN CUSTOMER LOGIN");	
					DrawLine.drawLine("-", 60);
					
					DrawLine.drawLine("-", 60);
					break;
				case 3:
					System.out.println("YOU HAVE CHOOSEN SEARCH CUSTOMER");
					DrawLine.drawLine("-", 60);
					System.out.println("Enter customer id/name to continue....");
					
					CustomerService cs= new CustomerServiceImpl();
					try {
						int name=scan.nextInt();
						List<Customer> custList=cs.search(name);
						if (custList.size()==0) {
							
						} else {
							for (Customer c:custList) {
								System.out.println(c.toString());
							}
						}
						
					} catch (Exception e) {
						
						String name=scan.nextLine();
						
						List<Customer> custList=cs.search(name);
						if (custList.size()==0) {
							System.out.println("No Customer available with the provided Customer Name.");
						} else {
							for (Customer c:custList) {
								System.out.println(c.toString());
							}
						}
						
						// TODO: handle exception
					}
					DrawLine.drawLine("-", 60);
					break;
				case 4:
					System.out.println("YOU HAVE CHOOSEN VIEW ALL CUSTOMERS");
					DrawLine.drawLine("-", 60);
					CustomerService customer = new CustomerServiceImpl();
					List<Customer> allCustomers=customer.getAllCustomers();
					if (allCustomers.size()==0) {
						System.out.println("There are no customers at the moment.");
					} else {
						for(Customer c: allCustomers) {
							System.out.println(c.toString());
							DrawLine.drawLine("-/", 30);
						}
					}
					
					
					DrawLine.drawLine("-", 60);
					break;
				case 5:
					System.out.println("YOU HAVE CHOOSEN TO ADD TOY");
					DrawLine.drawLine("-", 60);
					ToyService ts = new ToyServiceImpl();
					try {
						int toy_Id=0;
						String toy_Name="";
						String toy_Type="";
						float min_Age=0;
						float max_age=0;
						float price=0;
						int quantity=0;
						float rental_Amount=0;
						System.out.println("Enter Toy_Id: ");
						toy_Id=Integer.parseInt(JOptionPane.showInputDialog("Toy_Id"));
						
						//System.out.println("Enter Toy_Name: ");
						toy_Name=JOptionPane.showInputDialog("Toy_Name");
						//System.out.println("Enter Toy_Type: ");
						toy_Type=JOptionPane.showInputDialog("Toy_Type");
						//System.out.println("Enter Minimum_Age: ");
						min_Age=Float.parseFloat(JOptionPane.showInputDialog("Minimum Age"));
						//System.out.println("Enter Maximum_Age: ");
						max_age= Float.parseFloat(JOptionPane.showInputDialog("Maximum Age"));
						//System.out.println("Enter Price: ");
						price= Float.parseFloat(JOptionPane.showInputDialog("Toy Price"));
						//System.out.println("Enter Quantity: ");
						quantity= Integer.parseInt(JOptionPane.showInputDialog("Toy Quantity/Units"));
						//System.out.println("Enter Rental_Amount: ");
						rental_Amount=Float.parseFloat(JOptionPane.showInputDialog("Rental Price"));
						Toy toy = new Toy(toy_Id, toy_Name, toy_Type, min_Age, max_age, price, quantity, rental_Amount);
								ts.insertToy(toy);
					} catch (Exception e) {
						// TODO: handle exception
					System.out.println(e.getMessage());
					}
					
					
					
					
					DrawLine.drawLine("-", 60);
					break;
				case 6:
					System.out.println("YOU HAVE CHOOSEN TO SEARCH TOY");
					DrawLine.drawLine("-", 60);
					System.out.println("Enter Toy id/name to continue....");
					ToyService toyService = new ToyServiceImpl();
					try {
						int name=scan.nextInt();
						List<Toy> toyList=toyService.searchToy(name);
						if (toyList.size()==0) {
							System.out.println("There are no Toys related to provided Toy Id");
						} else {
							for (Toy t:toyList) {
								System.out.println(t.toString());
							}
						}
						
					} catch (Exception e) {
						
						String name=scan.nextLine();
						
						List<Toy> toyList=toyService.searchToy(name);
						if (toyList.size()==0) {
							System.out.println("There are no Toys related to provided Toy Name");
						} else {
							for (Toy t:toyList) {
								System.out.println(t.toString());
							}
						}
						
					}
					DrawLine.drawLine("-", 60);
					break;
				case 7:
					System.out.println("YOU HAVE CHOOSEN TO VIEW ALL TOYS");
					DrawLine.drawLine("-", 60);
					ToyService toys= new ToyServiceImpl();
					List<Toy> toyList = toys.getAllToys();
					if(toyList.size()==0) {
						System.err.println("Sorry, There are no toys to be displayed.");
					}
					else {
						for(Toy t:toyList) {
							System.out.println(t.toString());
							DrawLine.drawLine("-/", 60);
						}
					}
					
					DrawLine.drawLine("-", 60);
					break;
				case 8:
					System.out.println("YOU HAVE CHOOSEN TO BOOK A TOY");
					DrawLine.drawLine("-", 60);
					ToyRentalService trs = new ToyRentalServiceImpl();
					
					try {
						trs.bookToy();
					} catch (Exception e) {
						// TODO: handle exception
						e.getMessage();
					}
					DrawLine.drawLine("-", 60);
					break;
				case 9:
					System.out.println("YOU HAVE CHOOSEN TO RETURN A TOY");
					DrawLine.drawLine("-", 60);
					ToyRentalService trsReturnToy = new ToyRentalServiceImpl();
					try {
						trsReturnToy.returnToy();
					} catch (Exception e) {
						// TODO: handle exception
					}
					DrawLine.drawLine("-", 60);
					break;
			default:
				break;
			}
			String userInput =JOptionPane.showInputDialog("Do you Want to Continue(Y/N)");
			if(userInput.equalsIgnoreCase("y")) {
				doYouWantToContinue=true;
			}
		} while (doYouWantToContinue);
		
		
		
		
		
		System.exit(0);
		ToyRentalService trs = new ToyRentalServiceImpl();

		trs.returnToy();
		
		
		CustomerService cs= new CustomerServiceImpl();
//		Customer custNew = new Customer(5426, "FirstCustomer", "hdfhi434k", "First City", "FirstState", 541236, "FirstCountry");
//		
//		cs.insert(custNew);
//		custNew = new Customer(5428, "SecondCustomer", "sdf344*", "Second City", "SecondState", 142578, "SecondCountry");
//		cs.insert(custNew);
		List<Customer> cList=cs.getAllCustomers();
		List<Customer> cListsearch1=cs.search(5426);
//		for(Customer c:cList) {
//			c.toString();
//		}
		for(Customer c:cListsearch1) {
			System.out.println(c.toString());
		}
		List<Customer> cListsearch2=cs.search("SecondCustomer");
		for(Customer c:cListsearch2) {
			System.out.println(c.toString());
		}
//		for(Customer c:cList) {
//			System.out.println(c.toString());
//		}
		
		////////////////////////////////Adding Toys//////////////////////////////////
		System.out.println("//////////////////////////////Adding Toys//////////////////////////////////");
		ToyService toyService= new ToyServiceImpl();
//		Toy toy = new Toy(906, "Cycle", "Movable", 6, 12, 3600.25f, 50, 100);
//		boolean added =toyService.insertToy(toy);
//		if(added) {
//			System.out.println("Toy added successfully");
//		}
		List<Toy> toylist1=toyService.searchToy("Boomerang");
		
		for(Toy t:toylist1) {
			System.out.println(t.toString());
		}
	}

}
