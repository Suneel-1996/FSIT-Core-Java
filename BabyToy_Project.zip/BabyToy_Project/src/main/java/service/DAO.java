package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DAO {
	//private static String driver="com.mysql.jdbc.Driver";
	private static String driver="com.mysql.cj.jdbc.Driver";
	//com.mysql.jdbc.Driver
	private static String url="jdbc:mysql://localhost";
	private static String uname="root";
	private static String pass="Oct2019*";
	
public static Connection getInitialConnection() throws ClassNotFoundException, SQLException {
		
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,uname,pass);
				
		return con;
	}
}
