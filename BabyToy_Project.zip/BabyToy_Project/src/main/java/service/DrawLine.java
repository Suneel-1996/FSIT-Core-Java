package service;

public class DrawLine {
	public static void drawLine(String symbol,int length){
		String val=symbol;
		for(int i=0;i<length;i++) {
			System.out.print(symbol);
			//symbol=symbol+""+val;
		}
		System.out.println("");
	}
}
