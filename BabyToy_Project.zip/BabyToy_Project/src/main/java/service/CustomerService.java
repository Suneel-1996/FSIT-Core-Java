package service;

import java.util.ArrayList;
import java.util.List;

import model.CustomException;
import model.Customer;

public interface CustomerService {
	public boolean insert(Customer customer) throws ClassNotFoundException ;
	public List<Customer> search(int customer_Id);
	public List<Customer> search(String custName);
	public void display(int customer_Id);
	public List<Customer> getAllCustomers() throws CustomException;
}
