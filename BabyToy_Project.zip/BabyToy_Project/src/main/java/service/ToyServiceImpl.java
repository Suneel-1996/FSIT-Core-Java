package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Customer;
import model.Toy;

public class ToyServiceImpl implements ToyService{
static ArrayList<Toy> toyList = new ArrayList<Toy>();
	public boolean insertToy(Toy toy) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		toyList.add(toy);
		/*
		 JDBC code to be implemented
		 
		 */
		
		boolean created =false;
		
		try {
			Connection con = DAO.getInitialConnection();
			String insertQuery="insert into practice.toy(Toy_Id,Toy_Name, Toy_Type, Min_Age,Max_Age,Price,Quantity,Rental_Amount) values(?,?,?,?,?,?,?,?);";
			PreparedStatement preparedStatement = con.prepareStatement(insertQuery);
			preparedStatement.setInt(1, toy.getToy_Id());
			preparedStatement.setString(2, toy.getToy_Name());
			preparedStatement.setString(3, toy.getToy_Type());
			preparedStatement.setFloat(4, toy.getMin_Age());
			preparedStatement.setFloat(5, toy.getMax_age());
			preparedStatement.setFloat(6, toy.getPrice());
			preparedStatement.setInt(7, toy.getQuantity());
			preparedStatement.setFloat(8, toy.getRental_Amount());
			created = preparedStatement.execute();
			created=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Added");
		return created;
	}

	public List<Toy> searchToy(int toy_Id) {
		// TODO Auto-generated method stub
		String searchToy = "Select * from practice.toy where Toy_Id="+toy_Id+";";
		List<Toy> searchToyArray= new ArrayList<Toy>();
		//searchCustArray=null;
		try {
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs= statement.executeQuery(searchToy);
			while(rs.next()) {
				Toy toy = new Toy();
				toy.setToy_Id(rs.getInt(1));
				toy.setToy_Name(rs.getString(2));
				toy.setToy_Type(rs.getString(3));
				toy.setMin_Age(rs.getFloat(4));
				toy.setMax_age(rs.getFloat(5));
				toy.setPrice(rs.getFloat(6));
				toy.setQuantity(rs.getInt(7));
				toy.setRental_Amount(rs.getFloat(8));
				searchToyArray.add(toy);
				
			}
			//ResultSet rs = statement.executeQuery(allCustomers);
		} catch (Exception e) {
			// TODO: handle exception
		}
//		for(Toy t:toyList) {
//			if(t.getToy_Id()==toy_Id) {
//				searchToyArray.add(t);
//			}
//		}
		return searchToyArray;
	}

	public void display(int toy_Id) {
		// TODO Auto-generated method stub
		
	}

	public List<Toy> getAllToys() {
		// TODO Auto-generated method stub
String searchToy = "Select * from practice.toy;";
		
		List<Toy> listAllToys= new ArrayList<Toy>();
		//searchCustArray=null;
		try {
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs= statement.executeQuery(searchToy);
			while(rs.next()) {
				Toy toy = new Toy();
				toy.setToy_Id(rs.getInt(1));
				toy.setToy_Name(rs.getString(2));
				toy.setToy_Type(rs.getString(3));
				
				toy.setMin_Age(rs.getFloat(4));
				toy.setMax_age(rs.getFloat(5));
				toy.setPrice(rs.getFloat(6));
				toy.setQuantity(rs.getInt(7));
				toy.setRental_Amount(rs.getFloat(8));
				listAllToys.add(toy);
				
				
			}
			//ResultSet rs = statement.executeQuery(allCustomers);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
//		for(Toy t:toyList) {
//			if(t.getToy_Id()==toy_Id) {
//				searchToyArray.add(t);
//			}
//		}
		
		return listAllToys;
	}

	

	public List<Toy> searchToy(String toy_Name) {
		// TODO Auto-generated method stub
		String searchToy = "Select * from practice.toy where Toy_Name='"+toy_Name+"';";
		
		List<Toy> searchToyArray= new ArrayList<Toy>();
		//searchCustArray=null;
		try {
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs= statement.executeQuery(searchToy);
			while(rs.next()) {
				Toy toy = new Toy();
				toy.setToy_Id(rs.getInt(1));
				toy.setToy_Name(rs.getString(2));
				toy.setToy_Type(rs.getString(3));
				
				toy.setMin_Age(rs.getFloat(4));
				toy.setMax_age(rs.getFloat(5));
				toy.setPrice(rs.getFloat(6));
				toy.setQuantity(rs.getInt(7));
				toy.setRental_Amount(rs.getFloat(8));
				searchToyArray.add(toy);
				
				
			}
			//ResultSet rs = statement.executeQuery(allCustomers);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
//		for(Toy t:toyList) {
//			if(t.getToy_Id()==toy_Id) {
//				searchToyArray.add(t);
//			}
//		}
		
		return searchToyArray;
	}

}
