package service;

import java.util.List;

import model.Toy;
import model.Toy_Rental;

public interface ToyRentalService {
public boolean bookToy();
public List<Toy> returnToy();
public List<Toy_Rental> getRentalDetails(int customer_Id);
public void toyRentDetails(int toy_Id);
public void getTotalRentAmount();

}
