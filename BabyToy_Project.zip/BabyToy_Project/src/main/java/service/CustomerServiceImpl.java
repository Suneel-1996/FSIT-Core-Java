package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.CustomException;
import model.Customer;

public class CustomerServiceImpl implements CustomerService{
static ArrayList<Customer> custArray= new ArrayList<Customer>();
	public boolean insert(Customer customer) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean created =false;
		custArray.add(customer);
		/*
		 JDBC code to be implemented
		 
		 */
		
		try {
			Connection con = DAO.getInitialConnection();
			String insertQuery="insert into practice.customer(Customer_Id,Customer_Name, Password, City,State,Zip,Country) values(?,?,?,?,?,?,?);";
			PreparedStatement preparedStatement = con.prepareStatement(insertQuery);
			preparedStatement.setInt(1, customer.getCustomer_Id());
			preparedStatement.setString(2, customer.getCustomer_Name());
			preparedStatement.setString(3, customer.getPassword());
			preparedStatement.setString(4, customer.getCity());
			preparedStatement.setString(5, customer.getState());
			preparedStatement.setLong(6, customer.getZip());
			preparedStatement.setString(7, customer.getCountry());
			created = preparedStatement.execute();
			System.out.println("Customer "+customer.getCustomer_Id()+" added succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Cannot add customer. ");
			e.printStackTrace();
		}
		
		
		return created;
	}

	public List<Customer> search(int customer_Id) {
		String searchCustomer = "Select * from practice.customer where Customer_Id="+customer_Id+";";
		// TODO Auto-generated method stub
		//System.out.println(searchCustomer);
		List<Customer> searchCustArray= new ArrayList<Customer>();
		//searchCustArray=null;
		try {
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs= statement.executeQuery(searchCustomer);
			//System.out.println(rs.next());
			
			while(rs.next()) {
				Customer customer = new Customer();
				customer.setCustomer_Id(rs.getInt(1));
				customer.setCustomer_Name(rs.getString(2));
				customer.setPassword(rs.getString(3));
				customer.setCity(rs.getString(4));
				customer.setState(rs.getString(5));
				customer.setZip(rs.getLong(6));
				customer.setCountry(rs.getString(7));
				searchCustArray.add(customer);
			}
			//ResultSet rs = statement.executeQuery(allCustomers);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		
		
//		for(Customer c:custArray) {
//			if(c.getCustomer_Name().equalsIgnoreCase(custName)) {
//				searchCustArray.add(c);
//			}
//		}
		return searchCustArray;
	}

	public void display(int customer_Id) {
		// TODO Auto-generated method stub
		
	}

	public List<Customer> getAllCustomers() throws CustomException {
		// TODO Auto-generated method stub
		List<Customer> returnCustList=new ArrayList<Customer>();
		String allCustomers= "Select * from practice.customer";
		try {
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(allCustomers);
			while(rs.next()) {
				Customer customer = new Customer();
				customer.setCustomer_Id(rs.getInt(1));
				
				customer.setCustomer_Name(rs.getString(2));
				customer.setPassword(rs.getString(3));
				customer.setCity(rs.getString(4));
				customer.setState(rs.getString(5));
				customer.setZip(rs.getLong(6));
				customer.setCountry(rs.getString(7));
				returnCustList.add(customer);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		for(Customer cust:custArray) {
//			returnCustList.add(cust);
//		}
		return returnCustList;
	}

	public List<Customer> search(String custName) {
		String searchCustomer = "Select * from practice.customer where Customer_Name='"+custName+"';";
		// TODO Auto-generated method stub
		//System.out.println(searchCustomer);
		List<Customer> searchCustArray= new ArrayList<Customer>();
		//searchCustArray=null;
		try {
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs= statement.executeQuery(searchCustomer);
			while(rs.next()) {
				Customer customer = new Customer();
				customer.setCustomer_Id(rs.getInt(1));
				customer.setCustomer_Name(rs.getString(2));
				customer.setPassword(rs.getString(3));
				customer.setCity(rs.getString(4));
				customer.setState(rs.getString(5));
				customer.setZip(rs.getLong(6));
				customer.setCountry(rs.getString(7));
				searchCustArray.add(customer);
			}
			//ResultSet rs = statement.executeQuery(allCustomers);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		
		
//		for(Customer c:custArray) {
//			if(c.getCustomer_Name().equalsIgnoreCase(custName)) {
//				searchCustArray.add(c);
//			}
//		}
		return searchCustArray;
	}

}
