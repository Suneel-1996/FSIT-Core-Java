package service;

import java.util.ArrayList;
import java.util.List;

import model.Customer;
import model.Toy;

public interface ToyService {
	public boolean insertToy(Toy toy) throws ClassNotFoundException ;
	public List<Toy> searchToy(int toy_Id);
	public List<Toy> searchToy(String toy_Name);
	public void display(int toy_Id);
	public List<Toy> getAllToys();
}
