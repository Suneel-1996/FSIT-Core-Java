package service;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import model.Customer;
import model.Toy;
import model.Toy_Rental;

public class ToyRentalServiceImpl implements ToyRentalService{
public int maxRentalId() {
	int maxRentalId=0;
	try {
		String maxRentalIdQuery = "Select max(rental_id) from practice.toy_rental;";
		Connection con = DAO.getInitialConnection();
		Statement statement = con.createStatement();
		ResultSet rs= statement.executeQuery(maxRentalIdQuery);
		while (rs.next()) {
			maxRentalId=rs.getInt(1);
			
		}
	} catch (Exception e) {
		// TODO: handle exception
		System.out.println(e.getMessage());
	}
	return maxRentalId;
}
	public boolean bookToy() {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal= Calendar.getInstance();
		CustomerService cs = new CustomerServiceImpl();
		Boolean created;
		ToyService ts = new ToyServiceImpl();
		Scanner scan= new Scanner(System.in);
		
		System.out.println("Enter you customer Id : ");
		int customer_Id = scan.nextInt();
		List<Customer> custList=cs.search(customer_Id);
		
		if(custList.size()>0) {
			Customer cust=custList.get(0);
			System.out.println("Please Enter your password: ");
			String password=scan.next();
			
			if(password.equals(cust.getPassword())) {
			for(Customer c:custList) {
				System.out.println("Welcome "+c.getCustomer_Name()+". Please select a toy from the below.");
				DrawLine.drawLine("*",30);
			}
			//Listing Toys to customer
			List<Toy> toys = ts.getAllToys();
			for(Toy t: toys) {
				System.out.println(t.toString());
				DrawLine.drawLine("-", 30);
			}
			
			//Taking booking details from customer
			
			System.out.println("Enter the Toy Id you wanna book: ");
			int toy_Id = scan.nextInt();
			
			List<Toy> searchToyRes=ts.searchToy(toy_Id);
			
			if(searchToyRes.size()>0) {
				System.out.println("Enter for how many days you wanna book: ");
				int days = scan.nextInt();
				System.out.println("Enter the number of units you wanna book: ");
				int quan= scan.nextInt();
				Toy toy=searchToyRes.get(0);
				if(quan<=toy.getQuantity()) {
				
				try {
					Connection con = DAO.getInitialConnection();

					
					
					String insertQuery="insert into practice.Toy_Rental(Rental_Id,Customer_Id, Toy_Id, Rental_Start_Date,Rental_End_Date,Rental_Amount_Per_Day,Total_Amount,Fine,Status) values(?,?,?,?,?,?,?,?,?);";
					PreparedStatement preparedStatement = con.prepareStatement(insertQuery);
					preparedStatement.setInt(1, maxRentalId()+1);
					preparedStatement.setInt(2, customer_Id);
					preparedStatement.setInt(3, toy_Id);
					preparedStatement.setString(4,sdf.format(cal.getTime()));
					cal.add(Calendar.DAY_OF_MONTH, days);
					preparedStatement.setString(5, sdf.format(cal.getTime()));
					cal.add(Calendar.DAY_OF_MONTH, -days);
					preparedStatement.setFloat(6, toy.getRental_Amount());
					preparedStatement.setFloat(7, toy.getRental_Amount()*days*quan);
					preparedStatement.setFloat(8, 0);
					preparedStatement.setString(9, "Booked "+quan+" units of "+toy.getToy_Name()+" for "+days+" days.");
					created = preparedStatement.execute();
					
					System.out.println("Toy "+toy_Id+" booked successfully.");
					
					
					
				} catch (Exception e) {
					// TODO: handle exception
					System.out.println(e.getMessage());
				}
			}
				else {
					System.out.println("Sorry, Quantity entered is more than available......");
				}
			}
			else {
				System.out.println("Sorry, You Have entered Incorrect Toy Id......");
			}
		}
		else {
			System.out.println("Incorrect Password");
		}
		}
		else {
			System.out.println("Entered Customer Id doesnt exist....");
		}
		
		return false;
	}

	public List<Toy> returnToy() {
		// TODO Auto-generated method stub
		

		// TODO Auto-generated method stub
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal= Calendar.getInstance();
		CustomerService cs = new CustomerServiceImpl();
		Boolean created;
		ToyService ts = new ToyServiceImpl();
		Scanner scan= new Scanner(System.in);
		//String todayDate= sdf.parse(cal.getTime());
		System.out.println("Enter you customer Id : ");
		int customer_Id = scan.nextInt();
		List<Customer> custList=cs.search(customer_Id);
		
		if(custList.size()>0) {
			Customer cust=custList.get(0);
			System.out.println("Please Enter your password: ");
			String password=scan.next();
			
			if(password.equals(cust.getPassword())) {
			for(Customer c:custList) {
				System.out.println("Welcome "+c.getCustomer_Name()+". Please select a toy id from the below that you wanna return.");
				DrawLine.drawLine("*",30);
			}
			//Listing Toys to customer
			
			List<Toy_Rental> toyRental=getRentalDetails(customer_Id);
			
			
			//Taking booking details from customer
			
			
			
			if(toyRental.size()>0) {
				System.out.println("Enter the Toy Id you wanna return: ");
				int toy_Id = scan.nextInt();
				int rental_id=0;
				String from_date="";
				String to_date="";
				float fine =0;
				float rentalAmountPerDay=0;
				for(Toy_Rental tr:toyRental) {
					if(tr.getToy_Id()==toy_Id) {
						rental_id=tr.getRental_Id();
						from_date=tr.getRental_Start_Date();
						to_date=tr.getRental_End_Date();
						rentalAmountPerDay=tr.getRental_Amount_Per_Day();
					}
					
				}
				SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
				if (rental_id!=0) {
					try {
						
					      Date endDate = sdformat.parse(to_date);
					      Date submDate = sdformat.parse(sdf.format(cal.getTime()).toString());
					      long finedays=(submDate.getTime()-endDate.getTime())/(1000 * 60 * 60 * 24)%365;
					      
					      
						Connection con = DAO.getInitialConnection();
						String insertQuery="update practice.toy_rental set status='Returned on "+cal.getTime()+"',fine="+finedays*rentalAmountPerDay+" where customer_id='"+customer_Id+"' and toy_id='"+toy_Id+"';";
						PreparedStatement preparedStatement = con.prepareStatement(insertQuery);
//						preparedStatement.setString(1, "Returned on "+cal.getTime()+"");
//						preparedStatement.setInt(2, customer_Id);
//						preparedStatement.setInt(3, toy_Id);
						
						created = preparedStatement.execute();
						
						System.out.println("Toy "+toy_Id+" returned successfully.");
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println(e.getMessage());
					}
				} else {
System.out.println("Toy Id is not in your orders.");
				}
			}
			else {
				System.out.println("Sorry, There are no toys with your Id......");
			}
		}
		else {
			System.out.println("Incorrect Password");
		}
		}
		else {
			System.out.println("Entered Customer Id doesnt exist....");
		}
		
		return null;
	
	}
	public List<Toy_Rental> getRentalDetails(int customer_Id) {
		// TODO Auto-generated method stub
		List<Toy_Rental> toyRental= new ArrayList<Toy_Rental>();
		
		try {
			String maxRentalIdQuery = "Select * from practice.toy_rental where Customer_Id="+customer_Id+";";
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs= statement.executeQuery(maxRentalIdQuery);
			while (rs.next()) {
				//maxRentalId=rs.getInt(1);
				Toy_Rental tr= new Toy_Rental();
				tr.setRental_Id(rs.getInt(1));
				tr.setCustomer_Id(rs.getInt(2));
				tr.setToy_Id(rs.getInt(3));
				tr.setRental_Start_Date(rs.getDate(4).toString());
				tr.setRental_End_Date(rs.getDate(5).toString());
				tr.setRental_Amount_Per_Day(rs.getFloat(6));
				tr.setTotal_Amount(rs.getFloat(7));
				tr.setFine(rs.getFloat(8));
				tr.setStatus(rs.getString(9));
				System.out.println("Rental_Id: "+rs.getInt(1));
				System.out.println("Customer_Id: "+rs.getInt(2));
				System.out.println("Toy_Id: "+rs.getInt(3));
				System.out.println("Rental_Start_Date: "+rs.getDate(4));
				System.out.println("Rental_End_Date: "+rs.getDate(5));
				System.out.println("Rental_Amount_Per_Day: "+rs.getFloat(6));
				System.out.println("Total_Amount: "+rs.getFloat(7));
				System.out.println("Fine: "+rs.getFloat(8));
				System.out.println("Status: "+rs.getString(9));
				DrawLine.drawLine("-", 30);
				toyRental.add(tr);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return toyRental;
	}
	public void toyRentDetails(int toy_Id) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		
		try {
			String maxRentalIdQuery = "Select * from practice.toy_rental where Toy_Id="+toy_Id+";";
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs= statement.executeQuery(maxRentalIdQuery);
			while (rs.next()) {
				//maxRentalId=rs.getInt(1);
				System.out.println("Rental_Id: "+rs.getInt(1));
				System.out.println("Customer_Id: "+rs.getInt(2));
				System.out.println("Toy_Id: "+rs.getInt(3));
				System.out.println("Rental_Start_Date: "+rs.getDate(4));
				System.out.println("Rental_End_Date: "+rs.getDate(5));
				System.out.println("Rental_Amount_Per_Day: "+rs.getFloat(6));
				System.out.println("Total_Amount: "+rs.getFloat(7));
				System.out.println("Fine: "+rs.getFloat(8));
				System.out.println("Status: "+rs.getString(9));
				DrawLine.drawLine("-", 30);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	
		
	}
	public void getTotalRentAmount() {
		// TODO Auto-generated method stub
		
		try {
			String getTotalAmountQuery = "Select sum(total_amount+fine) from practice.toy_rental;";
			Connection con = DAO.getInitialConnection();
			Statement statement = con.createStatement();
			ResultSet rs= statement.executeQuery(getTotalAmountQuery);
			while (rs.next()) {
				//maxRentalId=rs.getInt(1);
				System.out.println(rs.getFloat(1));
				DrawLine.drawLine("-", 30);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}

}
